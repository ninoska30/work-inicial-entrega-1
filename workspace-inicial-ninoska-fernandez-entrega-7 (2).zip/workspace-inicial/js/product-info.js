//Función que se ejecuta una vez que se haya lanzado el evento de
//que el documento se encuentra cargado, es decir, se encuentran todos los
//elementos HTML presentes.
var comments = {};
var products = [];
var productsArray = [];
const estrellasPintadas = `<span class="fa fa-star checked"></span>` // es para algo que no va a cambiar.
const estrellasnoPintadas = `<span class="fa fa-star"></span>`
const infohtml = `
<ul class="list-group" style="position: relative; width:auto; top: 0;">
    <div class="card text-center"> 
         <div class="card-header">
            <li class="list-group-item list-group-item-secondary">`
 function showCommentsList(array){

    let htmlContentToAppend = "";

    for(let i = 0; i < array.length; i++){
        let comments = array[i];
        let estrellas = comments.score
        if(estrellas == 5){
        htmlContentToAppend += infohtml + estrellasPintadas + estrellasPintadas + estrellasPintadas + estrellasPintadas + estrellasPintadas +`</li>
            </div>

                <div class="card-body">
                    <li class="list-group-item">`+ comments.description + `</li>     
                    <li class="list-group-item card-text">` + comments.user + `</li>
                </div>
                <div class="card-footer text-muted">
                    <li class="list-group-item list-group-item-secondary">` + comments.dateTime + `</li>  
                </div>
        </ul><br>
        `
        }
        if(estrellas == 4){
            htmlContentToAppend += infohtml + estrellasPintadas + estrellasPintadas + estrellasPintadas + estrellasPintadas + estrellasnoPintadas +`</li>
                </div>
                    <div class="card-body">
                        <li class="list-group-item">`+ comments.description +`</li>
                        <li class="list-group-item">` + comments.user + `</li>
                    </div>
                    <div class="card-footer text-muted">
                        <li class="list-group-item list-group-item-secondary">` + comments.dateTime + `</li>  
                    </div>
            </ul><br>
            `
            }
            if(estrellas == 3){
                htmlContentToAppend += infohtml + estrellasPintadas + estrellasPintadas + estrellasPintadas + estrellasnoPintadas + estrellasnoPintadas +`</li>
                    </div>
                        <div class="card-body">
                            <li class="list-group-item">`+ comments.description +`</li>    
                            <li class="list-group-item">` + comments.user + `</li>
                        </div>
                        <div class="card-footer text-muted">    
                            <li class="list-group-item list-group-item-secondary">` + comments.dateTime + `</li>  
                        </div>
                </ul><br>
                `
                }
                if(estrellas == 2){
                    htmlContentToAppend += infohtml +  estrellasPintadas + estrellasPintadas + estrellasnoPintadas+ estrellasnoPintadas + estrellasnoPintadas +`</li>
                        </div>
                            <div class="card-body">
                                <li class="list-group-item">`+ comments.description +`</li>
                                <li class="list-group-item">` + comments.user + `</li>
                            </div>
                            <div class="card-footer text-muted">
                                <li class="list-group-item list-group-item-secondary">` + comments.dateTime + `</li>  
                            </div>
                    </ul><br>
                    `
                    }
                    if(estrellas == 1){
                        htmlContentToAppend += infohtml + estrellasPintadas + estrellasnoPintadas + estrellasnoPintadas + estrellasnoPintadas + estrellasnoPintadas +`</li>
                            </div>
                                <div class="card-body">
                                    <li class="list-group-item">`+ comments.description +`</li>    
                                    <li class="list-group-item">` + comments.user + `</li>
                                </div>
                                <div class="card-footer text-muted">
                                    <li class="list-group-item list-group-item-secondary">` + comments.dateTime + `</li>  
                                </div>
                        </div>
</ul><br>
`
                        }
        document.getElementById("commentsEstrellas").innerHTML = htmlContentToAppend;
    }
}
function nuevocomments(){
    var usuariologueado = sessionStorage.getItem("usuariologueado");
    let textarea = document.getElementById("mensaje").value;
    let comments = document.getElementById("cantidadestrellas").value;
    let mostrarError = document.getElementById("error");
    var hoy = new Date()
    var fecha = hoy.getDate() + '-' + (hoy.getMonth() + 1) + '-' + hoy.getFullYear();//parte del trabajo en grupo
    var hora = hoy.getHours() + ':' + hoy.getMinutes() + ':' + hoy.getSeconds();
     if( textarea == ""|| comments == ""){
         mostrarError.innerHTML = "Ingrese un Comentario"
     }  else{  var agregar = ""
     agregar += infohtml + `
    <ul class="list-group">
    <div class="card text-center">
    <div class="card-header"> 
    <li class="list-group-item list-group-item-secondary">`+ compararScore(comments) +`</li>
    </div>
    <div class="card-body">
    <li class="list-group-item">`+ textarea +`</li>
    <li class="list-group-item">`+ usuariologueado +`</li>
    </div>
    <div class="card-footer text-muted">
    <li class="list-group-item list-group-item-secondary">`+ fecha +" " + hora +`</li>
    </div>
 </div>
 </ul>
 `
 document.getElementById("commentsEstrellas").innerHTML += agregar;
  } 
} 

 function compararScore(estrellas){         //para que aparezca la cantidad de estrewllas deseadas
    let html = '';
    if (estrellas == 5) {
        html += `<p class="clasificacion">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
</p> `
        return html;
    }
    if (estrellas == 4) {
        html += `<p class="clasificacion">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span>
</p> `
        return html;
    }
    if (estrellas == 3) {
        html += `<p class="clasificacion">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span>
        <span class="fa fa-star"></span>
</p> `
        return html;
    }
    if (estrellas == 2) {
        html += `<p class="clasificacion">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span>
        <span class="fa fa-star"></span>
        <span class="fa fa-star"></span>
</p> `
        return html;
    }
    if (estrellas == 1) {
        html += `<p class="clasificacion">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span>
        <span class="fa fa-star"></span>
        <span class="fa fa-star"></span>
        <span class="fa fa-star"></span>
</p> `
        return html;
    }
 }

//Función que se ejecuta una vez que se haya lanzado el evento de
//que el documento se encuentra cargado, es decir, se encuentran todos los
//elementos HTML presentes.
document.addEventListener("DOMContentLoaded", function(_e){
    getJSONData(PRODUCT_INFO_COMMENTS_URL).then(function(resultObj){
        if (resultObj.status === "ok")
        {
            commentsArray = resultObj.data;

            //Muestro las imagenes en forma de galería
            showCommentsList(commentsArray);
        }
    });
});

function showImagesGallery(array){

    let htmlContentToAppend = "";

    for(let i = 0; i < array.length; i++){
        let imgSrc = array[i];

        htmlContentToAppend += `
        <div class="col-lg-3 col-md-4 col-6">
            <div class="d-block mb-4 h-100">
                <img class="img-fluid img-thumbnail" src="` + imgSrc + `" alt="">
            </div>
        </div>
        `

        document.getElementById("productImagesGallery").innerHTML = htmlContentToAppend;
    }
}
/*function showProductsinfo(array){

    let htmlContentToAppend = "";

    for(let i = 0; i < array.length; i++){
        let products = array[i];

        htmlContentToAppend += `
        <div class="card-body" class="list-group-item list-group-item-action">
            <div class="row">
                    <div class="d-flex w-100 justify-content-between">
                        <h4 class="mb-1">`+ category +`</h4>
                        <h4 class="mb-1">`+ products.currency + products.cost +`</h4>
                        <small class="hola">` + products.soldCount + ` Artículos</small>
                    </div>
            </div>        
        </div>
        `

        document.getElementById("cat-list-container").innerHTML = htmlContentToAppend;
    }
} idea que no funciono cuando queria mostrar los detalles*/

//Función que se ejecuta una vez que se haya lanzado el evento de
//que el documento se encuentra cargado, es decir, se encuentran todos los
//elementos HTML presentes.
document.addEventListener("DOMContentLoaded", function(_e){
    getJSONData(PRODUCT_INFO_URL).then(function(resultObj){
        if (resultObj.status === "ok")
        {
            products = resultObj.data;
            productsArray = resultObj.data;

            let productsNameHTML  = document.getElementById("productsName");
            let productsDescriptionHTML = document.getElementById("productsDescription");
            let productsCountHTML = document.getElementById("productsCount");
            let productsCriteriaHTML = document.getElementById("productsCriteria");
            let productsCategoryHTML = document.getElementById("productsCategory");
            
        
            productsNameHTML.innerHTML = products.name;
            productsDescriptionHTML.innerHTML = products.description;
            productsCountHTML.innerHTML = products.soldCount;//no me reconocia la funcion porque la estaba llamando mal
            productsCriteriaHTML.innerHTML = products.cost;
            productsCategoryHTML.innerHTML = products.category;

            //Muestro las imagenes en forma de galería
            showImagesGallery(products.images);

            //showProductsinfo(productsArray);
        }
    });
});
// Get the modal
var modal = document.getElementById("myModal2");

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById("myImg2");
var modalImg = document.getElementById("img02");
var captionText = document.getElementById("caption2");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}
function openModal() {
    document.getElementById("myModal2").style.display = "block";
  }
  
  function closeModal() {
    document.getElementById("myModal2").style.display = "none";
  }
/*Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
}*/
// Get the modal
var modal = document.getElementById("myModal4");

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById("myImg4");
var modalImg = document.getElementById("img04");
var captionText = document.getElementById("caption4");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}
function openModal() {
    document.getElementById("myModal4").style.display = "block";
  }
  
  function closeModal() {
    document.getElementById("myModal4").style.display = "none";
  }

/* Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[1];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
}*/

/*function relatedProducts(array){

    let htmlContentToAppend = "";

    for(let i = 0; i < array.length; i++){
        let imgSrc= array[i];

        htmlContentToAppend += `
        <a href="products.html" class="list-group-item list-group-item-action">
            <div class="col-lg-3 col-md-4 col-6">
                <div class="d-block mb-4 h-100">
                    <img src="` + imgSrc.img/prod2.jpg + `" alt="` + imgSrc.img/prod4.jpg + `" class="img-thumbnail">
                </div>
            </div>
        </a>
        `  

        document.getElementById("productosRelacionados").innerHTML = htmlContentToAppend;
    }
}
 /*function one() {
    for (i = 0; i < elements.length; i++) {
      elements[i].style.flex = "100%";
    }
  }*/

/*document.addEventListener("DOMContentLoaded", function(_e){
    getJSONData(PRODUCT_INFO_URL).then(function(resultObj){
        if (resultObj.status === "ok")
        {
            related = resultObj.data;
            productsArray = resultObj.data;

            related[imgSrc[i]].images

            relatedProducts(related,productsArray);

            //showProductsinfo(productsArray);
        }
    });
});*/

//Función que se ejecuta una vez que se haya lanzado el evento de
//que el documento se encuentra cargado, es decir, se encuentran todos los
//elementos HTML presentes.
const obj = {nom: "Ninoska",ape: "",cumple: "",email: "",tel: ""};
const myJSON = JSON.stringify(obj);
perfil = window.localStorage;
//se le agrega un if para que no devuelva un json vacío
if(!perfil.getItem('perfil')){
perfil.setItem('perfil',myJSON);
}
function showData(){
  alert(perfil.getItem('nombre'))
  document.getElementById("validationfname").innerHTML= perfil.getItem('nombre');
}

function updateData(){
  var obj = perfil.getItem("perfil");
  var objetoPerfil = JSON.parse(obj);
  //var objetoPerfil= sessionStorage.getItem("usuariologueado");
  objetoPerfil.nom = document.getElementById("validationfname").value;
  objetoPerfil.ape = document.getElementById("validationlname").value;
  objetoPerfil.cumple = document.getElementById("validationbirthday").value;
  objetoPerfil.email = document.getElementById("validationcorreo").value;
  objetoPerfil.tel = document.getElementById("validationphone").value;
  obj = JSON.stringify(objetoPerfil);
  perfil.setItem('perfil',obj);
}
document.getElementById("guardardatos").addEventListener("click",updateData);

document.addEventListener("DOMContentLoaded", function (e) {
 var obj = perfil.getItem('perfil');
 var objetoPerfil = JSON.parse(obj);
 document.getElementById("validationfname").value = objetoPerfil.nom;
 document.getElementById("validationlname").value = objetoPerfil.ape;
 document.getElementById("validationbirthday").value = objetoPerfil.cumple;
 document.getElementById("validationcorreo").value = objetoPerfil.email;
 document.getElementById("validationphone").value = objetoPerfil.tel;
});
//botónes para habilitar y deshabilitar los campos para editar los datos
function campoDeshabilitado(){
  document.getElementById("validationfname").disabled = true
  document.getElementById("validationlname").disabled = true
  document.getElementById("validationbirthday").disabled = true
  document.getElementById("validationcorreo").disabled = true
  document.getElementById("validationphone").disabled = true
}
function campoHabilitado(){
  document.getElementById("validationfname").disabled = false
  document.getElementById("validationlname").disabled = false
  document.getElementById("validationbirthday").disabled = false
  document.getElementById("validationcorreo").disabled = false
  document.getElementById("validationphone").disabled = false
}
//De hecho esto no lo utilizo porque le saque la opción de validar datos.
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
    'use strict'
  
    // Fetch all the forms we want to apply custom Bootstrap validation styles to // aplica el estilo dado
    var forms = document.querySelectorAll('.needs-validation')
  
    // Loop over them and prevent submission //No permite guardar sino tiene datos
    Array.prototype.slice.call(forms)
      .forEach(function (form) {
        form.addEventListener('submit', function (event) {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }
  
          form.classList.add('was-validated')
        }, false)
      })
  })()
  
  window.onscroll = function() {scrollFunction()};
//función para que el avatar no se mueva de lugar cundo se scrollea
function scrollFunction() {
  if (document.body.scrollTop > 40 || document.documentElement.scrollTop > 40) {
    document.getElementById("avatar").style.fontSize = "30px";
  } else {
    document.getElementById("avatar").style.fontSize = "90px";
  }
}
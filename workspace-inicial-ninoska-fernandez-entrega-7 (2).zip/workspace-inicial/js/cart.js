//Función que se ejecuta una vez que se haya lanzado el evento de
//que el documento se encuentra cargado, es decir, se encuentran todos los
//elementos HTML presentes.
// Variables
const articles = [
    {
        name: "Pino de olor para el auto",
        count: 2,
        unitCost: 100,
        currency: "UYU",
        src: "img/tree1.jpg"
        /*id: 1,
        name: 'Patata',
        unitCost: 1,
        src: 'patata.jpg'
        /*name: "Chevrolet Oniarticles Joy",
        description: "Generación 2019, variedad de colores. Motor 1.0, ideal para ciudad.",
        unitCost: 13500,
        src: "img/prod1.jpg",*/
    },
];

let carrito = [];
let total = 0;
const DOMitems = document.querySelector('#items');
const DOMcarrito = document.querySelector('#carrito');
const DOMtotal = document.querySelector('#total');
const DOMtotal2 = document.querySelector('#total2');
const DOMbotonVaciar = document.querySelector('#boton-vaciar');


    function showArticles() {
        articles.forEach((info) => {
            // Estructura
            const miNodo = document.createElement('div');
            miNodo.classList.add('card', 'col-sm-4');
            // Body
            const miNodoCardBody = document.createElement('div');
            miNodoCardBody.classList.add('card-body');
            // Descripción
            const miNodoDescripción = document.createElement('h5');
            miNodoDescripción.classList.add('card-text');
            miNodoDescripción.textContent = (info.name);
            //Imagen Meramente ilustrativa
            const miNodoImagen = document.createElement('img');
            miNodoImagen.classList.add('card-img-top');
            miNodoImagen.setAttribute('Src', info.src)
            // Precio
            const miNodoPrecio = document.createElement('p');
            miNodoPrecio.classList.add('card-text');
            miNodoPrecio.textContent = `${info.unitCost}\$ + ${info.currency}`;
            // Boton 
            const miNodoBoton = document.createElement('button');
            miNodoBoton.classList.add('btn', 'btn-primary');
            miNodoBoton.textContent = 'Agregar al carrito';
            miNodoBoton.setAttribute('marcador', info.count);
            miNodoBoton.addEventListener('click', anyadirProductoAlCarrito);
            // Insertamos
            miNodoCardBody.appendChild(miNodoImagen);
            miNodoCardBody.appendChild(miNodoDescripción);
            miNodoCardBody.appendChild(miNodoPrecio);
            miNodoCardBody.appendChild(miNodoBoton);
            miNodo.appendChild(miNodoCardBody);
            DOMitems.appendChild(miNodo);
        });
    }

/**
 * Evento para añadir un producto al carrito de la compra
 */
function anyadirProductoAlCarrito(evento) {
    // Anyadimos el Nodo a nuestro carrito
    carrito.push(evento.target.getAttribute('marcador'))
    // Calculo el total
    calcularTotal();
    // Actualizamos el carrito 
    showCarrito();
    agregarTambien();
}

/**
 * Dibuja todos los productos guardados en el carrito
 */
function showCarrito() {
    // Vaciamos todo el html
    DOMcarrito.textContent = '';
    // Quitamos los duplicados
    const carritoSinDuplicados = [...new Set(carrito)];
    // Generamos los Nodos a partir de carrito
    carritoSinDuplicados.forEach((item) => {
        // Obtenemos el item que necesitamos de la variable base de datos
        const miItem = articles.filter((itemarticles) => {
            // ¿Coincide las id? Solo puede exisistir un caso
            return itemarticles.count === parseInt(item);
        });
        // Cuenta el número de veces que se repite el producto
        const numeroUnidadesItem = carrito.reduce((total, itemId) => {
            // ¿Coincide las id? Incremento el contador, en caso contrario no mantengo
            return itemId === item ? total += 1 : total;
        }, 0);
        // Creamos el nodo del item del carrito
        const miNodo = document.createElement('li');
        miNodo.classList.add('list-group-item', 'text-center', 'mx-2');
        miNodo.textContent = `${numeroUnidadesItem} Articulos ${miItem[0].name}`+" + "+ `$ ${miItem[0].unitCost}`;
        // Boton de borrar
        const miBoton = document.createElement('button');
        miBoton.classList.add('btn', 'btn-danger', 'mx-5');
        miBoton.textContent = 'Eliminar del Carrito';
        miBoton.style.marginLeft = '5rem';
        miBoton.dataset.item = item;
        miBoton.addEventListener('click', borrarItemCarrito);
        // Mezclamos nodos
        miNodo.appendChild(miBoton);
        DOMcarrito.appendChild(miNodo);
    });
}

/**
 * Evento para borrar un elemento del carrito
 */
function borrarItemCarrito(evento) {
    // Obtenemos el producto ID que hay en el boton pulsado
    const id = evento.target.dataset.item;
    // Borramos todos los productos
    carrito = carrito.filter((carritoId) => {
        return carritoId !== id;
    });
    // volvemos a renderizar
    showCarrito();
    // Calculamos de nuevo el precio
    calcularTotal();
    agregarTambien();
}

/**
 * Calcula el precio total teniendo en cuenta los productos repetidos
 */
function calcularTotal() {
    // Limpiamos precio anterior
    total = 0;
    // Recorremos el array del carrito
    carrito.forEach((item) => {
        // De cada elemento obtenemos su precio
        const miItem = articles.filter((itemarticles) => {
            return itemarticles.count === parseInt(item);
        });
        total = total + miItem[0].unitCost;
    });
    // Renderizamos el precio en el HTML
    DOMtotal.textContent = total.toFixed(2);
}
function agregarTambien() {
       // Limpiamos precio anterior
        total = 0;
        // Recorremos el array del carrito
        carrito.forEach((item) => {
            // De cada elemento obtenemos su precio
            const miItem2 = articles.filter((itemarticles) => {
                return itemarticles.count === parseInt(item);
            });
            total = total + miItem2[0].unitCost;
        });
        // Renderizamos el precio en el HTML
        DOMtotal2.textContent = total.toFixed(2);
    }
/**
 * Vacia el carrito y vuelve a dibujarlo
 */
function vaciarCarrito() {
    // Limpiamos los productos guardados
    carrito = [];
    // Renderizamos los cambios
    showCarrito();
    calcularTotal();
    agregarTambien();
}
// Eventos
DOMbotonVaciar.addEventListener('click', vaciarCarrito);

// Inicio
showArticles();
    
    //var x = document.getElementById("lista").value;
    //document.getElementById("demo").innerHTML = "You wrote: " + x;

$('#myModal').on('shown.bs.modal1', function () {
    $('#myInput').trigger('focus')
  })

// el modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal1
var btn = document.getElementById("button-addon1");

// Get the <span1> element that closes the modal1
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal1 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span1> (x), close the modal1
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal1, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
const obj = {nom: "Ninoska",ape: "",tel: "",email: "",adress: "",city: ""};
const myJSON = JSON.stringify(obj);
perfil = window.localStorage;
//se le agrega un if para que no devuelva un json vacío
if(!perfil.getItem('perfil')){
perfil.setItem('perfil',myJSON);
}
function showData(){
  alert(perfil.getItem('nombre'))
  document.getElementById("validationDefault01").innerHTML= perfil.getItem('nombre');
}

function updateData(){
  var obj = perfil.getItem("perfil");
  var objetoPerfil = JSON.parse(obj);
  //var objetoPerfil= sessionStorage.getItem("usuariologueado");
  objetoPerfil.nom = document.getElementById("validationDefault01").value;
  objetoPerfil.ape = document.getElementById("validationDefault02").value;
  objetoPerfil.tel = document.getElementById("validationDefault08").value;
  objetoPerfil.email = document.getElementById("validationcorreo").value;
  objetoPerfil.adress = document.getElementById("validationDefault06").value;
  objetoPerfil.city = document.getElementById("validationDefault07").value;
  obj = JSON.stringify(objetoPerfil);
  perfil.setItem('perfil',obj);
}
document.getElementById("guardardatos").addEventListener("click",updateData);

document.addEventListener("DOMContentLoaded", function (e) {
 var obj = perfil.getItem('perfil');
 var objetoPerfil = JSON.parse(obj);
 document.getElementById("validationDefault01").value = objetoPerfil.nom;
 document.getElementById("validationDefault02").value = objetoPerfil.ape;
 document.getElementById("validationDefault08").value = objetoPerfil.tel;
 document.getElementById("validationcorreo").value = objetoPerfil.email;
 document.getElementById("validationDefault06").value = objetoPerfil.adress;
 document.getElementById("validationDefault07").value = objetoPerfil.city;
});

/*function myBoton(){
    var x = document.getElementById("myFactura");
    if(x.style.display === "block"){
        x.style.display = "none";
    }else{
        x.style.display = "block";
    }
}

function showElement(){
    var x = document.getElementById("myFactura");
    if (x.style.display === 'none') {
        x.style.display = 'block';
      }else {
        x.style.display = 'none';
      }
}*/

function valido(par1,par2){
    let forma = document.getElementById(par1);
    let avisoError = document.getElementById(par2);
    if(forma.value == ''){
        avisoError.style.display = "block";
        avisoError.innerHTML = "* Campo Obligatorio"
        //forma.classList.add("error");
    }else{
        forma.classList.remove("error");
    };
}
function formasPago() {
    var x = document.getElementById("myPago").value;
    document.getElementById("prueba").innerHTML = "You selected: " + x;
  }
  

  function cargarMsg(id, idMensaje){
    // validar NombrecargarMsg
    var elementNombre = document.getElementById(id);
    var elementError = document.getElementById(idMensaje);
    if(elementNombre.value == ''){
            elementError.style.display = "block";
            elementNombre.classList.add("error");      
    }else{
            elementNombre.classList.remove("error");
            elementError.innerHTML = "¡Has comprado con éxito!";
    }
  }
/*nuevo modal1 redirige a la factura
var modal1 =  document.getElementById("myFactura");
var boton = document.getElementById("continuar");
var span1 = document.getElementsByClassName("cerrar")[0];

 boton.onclick = function(){
     modal1.style.display = "block";
 }
span1.onclick = function(){
    modal1.style.display = "none";
}
//When the user clicks anywhere outside of the modal1, close it
window.onclick = function(event) {
    if (event.target == modal1) {
      modal1.style.display = "none";
    }
  }*/









/*function showArticlesCart(array){
    class="modal1-dialog modal1-dialog-scrollable">
    let htmlContentToAppend = "";
    for(let i = 0; i < array.length; i++){
        let articles = array[i];
        htmlContentToAppend += `
        <div class="list-group-item list-group-item-action">
            <div class="row">
                <div class="col-3">
                    <img src="` + articles.src + `" alt="` +  `" class="img-thumbnail">
                </div>
                <div class="col">
                    <div class="d-flearticles w-100 justify-myFactura-between">
                        <h4 class="mb-1">`+ articles.name +`</h4>
                        <h4 class="mb-1">`+ " $ "+ articles.unitCost + ' ' + articles.currency +`</h4>
                    </div>
                </div>
            </div>
        </div>
        `  
        }

        document.getElementById("items").innerHTML = htmlContentToAppend;
    }

document.addEventListener("DOMContentLoaded", function(e){
    showSpinner();
    getJSONData(CART_INFO_URL).then(function(resultObj){
        if (resultObj.status === "ok"){

            articlesArray = resultObj.data;
            //Muestro las categorías ordenadas
            showArticlesCart(articlesArray.articles);
            //showCart(articlesArray.articles);
            //document.getElementById('carrito').innerHTML=artículos;
            
        }
    });
});*/


/*const articles = [
    {
        name: "Pino de olor para el auto",
        count: 2,
        unitCost: 100,
        currency: "UYU",
        src: "img/tree1.jpg"
        /*id: 1,
        name: 'Patata',
        unitCost: 1,
        src: 'patata.jpg'
        /*name: "Chevrolet Oniarticles Joy",
        description: "Generación 2019, variedad de colores. Motor 1.0, ideal para ciudad.",
        unitCost: 13500,
        src: "img/prod1.jpg",
    },

    {
        name: "Fiat Way",
        count: 52,
        unitCost: 14500,
        currency: "USD",
        src: "img/prod2.jpg"
    },
];

let carrito = [];
let total = 0;
const DOMitems = document.querySelector('#items');
const DOMcarrito = document.querySelector('#carrito');
const DOMtotal = document.querySelector('#total');
const DOMbotonVaciar = document.querySelector('#boton-vaciar');

// Funciones

/**
 * Dibuja todos los productos a partir de la base de datos. No confundir con el carrito
 *
 function showCart() {
    articles.forEach((info) => {
        // Estructura
        const miNodo = document.createElement('div');
        miNodo.classList.add('card', 'col-sm-4');
        // Body
        const miNodoCardBody = document.createElement('div');
        miNodoCardBody.classList.add('card-body');
        // Precio
        const miNodoPrecio = document.createElement('p');
        miNodoPrecio.classList.add('card-tearticlest');
        miNodoPrecio.tearticlestContent = `${info.unitCost}\$`;
        // Boton 
        const miNodoBoton = document.createElement('button');
        miNodoBoton.tearticlestContent = 'Agregar al carrito';
        miNodoBoton.setAttribute('articles', info.i);
        miNodoBoton.addEventListener('click', anyadirProductoAlCarrito);
        // Insertamos
        miNodoCardBody.appendChild(miNodoPrecio);
        miNodoCardBody.appendChild(miNodoBoton);
        miNodo.appendChild(miNodoCardBody);
        DOMitems.appendChild(miNodo);
    });
}

/**
 * Evento para añadir un producto al carrito de la compra
 
function anyadirProductoAlCarrito(evento) {
    // Anyadimos el Nodo a nuestro carrito
    carrito.push(evento.target.getAttribute('articles'))
    // Calculo el total
    calcularTotal();
    // Actualizamos el carrito 
    showCarrito();

}

/**
 * Dibuja todos los productos guardados en el carrito
 
function showCarrito() {
    // Vaciamos todo el html
    DOMcarrito.tearticlestContent = '';
    // Quitamos los duplicados
    const carritoSinDuplicados = [...new Set(carrito)];
    // Generamos los Nodos a partir de carrito
    carritoSinDuplicados.forEach((item) => {
        // Obtenemos el item que necesitamos de la variable base de datos
        const miItem = articles.filter((itemarticles) => {
            // ¿Coincide las id? Solo puede earticlesistir un caso
            return itemarticles.id === parseInt(item);
        });
        // Cuenta el número de veces que se repite el producto
        const numeroUnidadesItem = carrito.reduce((total, itemId) => {
            // ¿Coincide las id? Incremento el contador, en caso contrario no mantengo
            return itemId === item ? total += 1 : total;
        }, 0);
        // Creamos el nodo del item del carrito
        const miNodo = document.createElement('li');
        miNodo.classList.add('list-group-item', 'tearticlest-right', 'marticles-2');
        miNodo.tearticlestContent = `${numeroUnidadesItem} articles ${miItem[0].nombre} - ${miItem[0].precio}$`;
        // Boton de borrar
        const miBoton = document.createElement('button');
        miBoton.classList.add('btn', 'btn-danger', 'marticles-5');
        miBoton.tearticlestContent = 'Eliminar';
        miBoton.style.marginLeft = '1rem';
        miBoton.dataset.item = item;
        miBoton.addEventListener('click', borrarItemCarrito);
        // Mezclamos nodos
        miNodo.appendChild(miBoton);
        DOMcarrito.appendChild(miNodo);
    });
}

/**
 * Evento para borrar un elemento del carrito
 
function borrarItemCarrito(evento) {
    // Obtenemos el producto ID que hay en el boton pulsado
    const id = evento.target.dataset.item;
    // Borramos todos los productos
    carrito = carrito.filter((carritoId) => {
        return carritoId !== id;
    });
    // volvemos a renderizar
    showCarrito();
    // Calculamos de nuevo el precio
    calcularTotal();
}

/**
 * Calcula el precio total teniendo en cuenta los productos repetidos
 
function calcularTotal() {
    // Limpiamos precio anterior
    total = 0;
    // Recorremos el array del carrito
    carrito.forEach((item) => {
        // De cada elemento obtenemos su precio
        const miItem = articles.filter((itemarticles) => {
            return itemarticles.id === parseInt(item);
        });
        total = total + miItem[0].precio;
    });
    // Renderizamos el precio en el HTML
    DOMtotal.tearticlestContent = total.toFiarticlesed(2);
}

/**
 * Varia el carrito y vuelve a dibujarlo
 
function vaciarCarrito() {
    // Limpiamos los productos guardados
    carrito = [];
    // Renderizamos los cambios
    showCarrito();
    calcularTotal();
}

// Eventos
DOMbotonVaciar.addEventListener('click', vaciarCarrito);

// Inicio
showrarticles();*/

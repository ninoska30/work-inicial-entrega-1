//Función que se ejecuta una vez que se haya lanzado el evento de
//que el documento se encuentra cargado, es decir, se encuentran todos los
//elementos HTML presentes.

function cargarError(id, idMensaje){
    // validar Nombre
    var elementNombre = document.getElementById(id);
    var elementError = document.getElementById(idMensaje);
    if(elementNombre.value == ''){
            elementError.style.display = "block";
            elementNombre.classList.add("error");
            elementError.innerHTML = "Campo obligatorio";      
    }else{
            var Nombreusuario = document.getElementById("fname");
            var GUARDARDATOS = sessionStorage.setItem("usuariologueado",Nombreusuario.value);
            elementNombre.classList.add("error");
    }
  }
  function login(){
        let usuario = document.getElementById("fname");
        let contra = document.getElementById("pswd");
        if (usuario.value !== '' && contra.value !== ''){            //Si los campos de usuario y contraseña no están vacíos
            sessionStorage.setItem("usuariologueado", usuario.value);       //Guardo el usuario
            window.location.replace("index.html");                   //Y se le lleva al index
        }
    }
  //funcion que no permite avanzar sino se rellena el login 
  //reutilizada de un trabajo realizado en clase

  document.addEventListener("DOMContentLoaded", function(e){
    login()
});
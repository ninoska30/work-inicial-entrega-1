const ORDENAR_ASC = "AZ";
const ORDENAR_DESC= "ZA";
const ORDENAR_VENDIDOS = "Cant.";
var currentProductsArray = [];
var currentSortCriteria = undefined;
var minCount = undefined;
var maxCount = undefined;
var resultado = "";
var productsArray = [];
//basado en el código de categories
function sortProducts(criteria, array){
    let result = [];
    if (criteria === ORDENAR_ASC)
    {
        result = array.sort(function(a, b) {
            if ( a.cost < b.cost ){ return -1; }
            if ( a.cost > b.cost ){ return 1; }
            return 0;
        });
    }else if (criteria === ORDENAR_DESC){
        result = array.sort(function(a, b) {
            if ( a.cost > b.cost ){ return -1; }
            if ( a.cost < b.cost ){ return 1; }
            return 0;
        });
    }else if (criteria === ORDENAR_VENDIDOS){
        result = array.sort(function(a, b) {
            let aCount = parseInt(a.soldCount);
            let bCount = parseInt(b.soldCount);

            if ( aCount > bCount ){ return -1; }
            if ( aCount < bCount ){ return 1; }
            return 0;
        });
    }

    return result;
}


//Función que se ejecuta una vez que se haya lanzado el evento de
//que el documento se encuentra cargado, es decir, se encuentran todos los
//elementos HTML presentes.
//Nota personal: al principio queria reutilizar otro código pero era más lógico útilizar este. 

function showProductsList(array){

    let htmlContentToAppend = "";
    for(let i = 0; i < currentProductsArray.length; i++){
        let products = currentProductsArray[i];
//código reciclado de ejercicio en clase grupal
//Se le agrega al código el atributo correspondiente para que lo pueda leer
//código copiado de la parte de categories
//El lenght no funcionaba porque le faltaba currentProductsArray
       if (((minCount == undefined) || (minCount != undefined && parseInt(products.soldCount) >= minCount)) &&
           ((maxCount == undefined) || (maxCount != undefined && parseInt(products.soldCount) <= maxCount))){

        htmlContentToAppend += `
        <a href="product-info.html" class="list-group-item list-group-item-action">
            <div class="row">
                <div class="col-3">
                    <img src="` + products.imgSrc + `" alt="` + products.desc + `" class="img-thumbnail">
                </div>
                <div class="col">
                    <div class="d-flex w-100 justify-content-between">
                        <h4 class="mb-1">`+ products.name +`</h4>
                        <h4 class="mb-1">`+ products.currency + products.cost +`</h4>
                        <small class="hola">` + products.soldCount + ` Artículos</small>
                    </div>
                    <small class="text-muted">` + products.description + `</small>  
                </div>
            </div>
        </a>
        `  
        }

        document.getElementById("cat-list-container").innerHTML = htmlContentToAppend;
    }
}
    function sortAndShowProducts(sortCriteria, productsArray) {
        currentSortCriteria = sortCriteria;

         if (productsArray != undefined) {
             currentProductsArray = productsArray;
    }

    currentProductsArray = sortProducts(currentSortCriteria, currentProductsArray);

    //Muestro las categorías ordenadas
    showProductsList();
}
//Función que se ejecuta una vez que se haya lanzado el evento de
//que el documento se encuentra cargado, es decir, se encuentran todos los
//elementos HTML presentes.
 document.addEventListener("DOMContentLoaded", function(e){
    showSpinner();
    getJSONData(PRODUCTS_URL).then(function(resultObj){
        if (resultObj.status === "ok"){
            productsArray = resultObj.data;
            //Muestro las categorías ordenadas
            sortAndShowProducts(ORDENAR_ASC, productsArray);
        }
    });
});

//Al principio utilice la palabra en ingles autos para hacerlo funcionar porque pense que era algo especifico.
//Lo cambie por products para que funcione para todos los productos.
 //lo ordena de menor a mayor*
    document.getElementById("sortAsc").addEventListener("click", function() {
        sortAndShowProducts(ORDENAR_ASC);
    });
    document.getElementById("sortDesc").addEventListener("click", function(){
        sortAndShowProducts(ORDENAR_DESC);
    });
//no funcionaba porque no estaba etuiquetado correctamente en el html
    document.getElementById("sortBySold").addEventListener("click", function(){
        sortAndShowProducts(ORDENAR_VENDIDOS);
    });

//no funcionaba porquye también estaba mal etuiquetado en el html
    document.getElementById("clearRangeFilter").addEventListener("click", function() {
        document.getElementById("rangeFilterSoldMin").value = "";
        document.getElementById("rangeFilterSoldMax").value = "";

        minCount = undefined;
        maxCount = undefined;

        showProductsList();
    });

    document.getElementById("rangeFilterSold").addEventListener("click", function() {

        minCount = document.getElementById("rangeFilterSoldMin").value;
        maxCount = document.getElementById("rangeFilterSoldMax").value;

        if ((minCount != undefined) && (minCount != "") && (parseInt(minCount)) >= 0) {
            minCount = parseInt(minCount);
        } else {
            minCount = undefined;
        }

        if ((maxCount != undefined) && (maxCount != "") && (parseInt(maxCount)) >= 0) {
            maxCount = parseInt(maxCount);
        } else {
            maxCount = undefined;
        }

        showProductsList();
    });
    
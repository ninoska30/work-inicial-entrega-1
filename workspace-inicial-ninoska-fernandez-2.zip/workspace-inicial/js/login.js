//Función que se ejecuta una vez que se haya lanzado el evento de
//que el documento se encuentra cargado, es decir, se encuentran todos los
//elementos HTML presentes.
document.addEventListener("DOMContentLoaded", function(e){

});

function cargarError(id, idMensaje){
    // validar Nombre
    var elementNombre = document.getElementById(id);
    var elementError = document.getElementById(idMensaje);
    if(elementNombre.value == ''){
            elementError.style.display = "block";
            elementNombre.classList.add("error");
            elementError.innerHTML = "Campo obligatorio";      
    }
    elementNombre.classList.add("error");
  }
  //funcion que no permite avanzar sino se rellena el login 
  //reutilizada de un trabajo realizado en clase